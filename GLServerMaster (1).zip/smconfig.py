from discord import Colour, Embed, utils
from os import getenv
from dotenv import load_dotenv


#emoticons
em_check = '<:Buenoverde:880853555873972224>'
em_cross = '<:896pxX_mark:880853554716360725>'
em_ban = ':no_entry:'
em_tools = ':tools:' 
em_world =':globe_with_meridians:'
em_book = ':bookmark:'

default_ban_time = '48h'

load_dotenv('token.env')
TOKEN = getenv('DISCORD_TOKEN')
GUILD = getenv('DISCORD_GUILD')
invoked = getenv('INVOKED')


colors = {
    'blue':Colour.blue(),
    'blurple':Colour.blurple(),
    'dark_blue':Colour.dark_blue(),
    'dark_gold':Colour.dark_gold(),
    'dark_gray':Colour.dark_gray(),
    'dark_green':Colour.dark_green(),
    'dark_grey':Colour.dark_grey(),
    'dark_magenta':Colour.dark_magenta(),
    'dark_orange':Colour.dark_orange(),
    'dark_purple':Colour.dark_purple(),
    'dark_red':Colour.dark_red(),
    'dark_teal':Colour.dark_teal(),
    'dark_theme':Colour.dark_theme(),
    'darker_gray':Colour.darker_gray(),
    'darker_grey':Colour.darker_grey(),
    'default':Colour.default(),
    'gold':Colour.gold(),
    'green':Colour.green(),
    'greyple':Colour.greyple(),
    'light_gray':Colour.light_gray(),
    'light_grey':Colour.light_grey(),
    'lighter_gray':Colour.lighter_gray(),
    'lighter_grey':Colour.lighter_grey(),
    'magenta':Colour.magenta(),
    'orange':Colour.orange(),
    'purple':Colour.purple(),
    'random':Colour.random(),
    'red':Colour.red(),
    'teal':Colour.teal()
}

usernullimg = 'https://i.postimg.cc/rsYMcRQY/image.png'
strikeimg = 'https://i.postimg.cc/xTk8Zj7m/strikegl.png'
banimg = 'https://i.postimg.cc/LsVjs6mX/banhammergl.png'
repairimg = 'https://i.postimg.cc/7YDcym58/glrepairs.png'
mainimg = 'https://i.postimg.cc/7Z47NPx0/glmain.png'


suhelp = Embed(
            title = em_book + " COMANDOS " + em_book,
            description = 'Los comandos disponibles son:',
            colour = colors.get('gold')
        )
suhelp.set_footer(text="si tienen mas dudas pregunten a Knotty o Arima.")
suhelp.add_field(name='!su getinfo <nick de MC, ID de Discord o mension (@) de Discord>', value='Da informacion de un jugador, su discord, nick de minecraft, id de discord y UUID de minecraft si esta disponible', inline=False)
suhelp.add_field(name='!su link <nick de MC> <@ de usuario de discord>', value='conecta un nick de minecraft con un usuario en discord', inline=False)
suhelp.add_field(name='!su wlremove <nick de minecraft>', value="""quita un nick de la whitelist de minecraft

este comando solo sirve para usuarios en la base de datos del bot, si el usuario no fue registrado con !wl utilice el comando !mc whitelist remove <nick>""", inline=False)
suhelp.add_field(name='!mc <comando>', value='permite ejecutar comandos de minecraft en el servidor', inline=False)
suhelp.add_field(name='!wl <nick de MC> <@ de usuario de discord>', value="""añade un usuario a la white list y conecta el nick de minecraft con el usuario en discord

si el jugador ya existe o ya registro otra cuenta, borrara la informacion anterior y lo volvera a registrar automaticamente""", inline=False)
suhelp.add_field(name='!wl <nick de minecraft> su', value='para uso personal del staff, es escencialmente el !wl pero para los admins/mods con la diferencia de que deja registrar multiples nicks de minecraft a la cuenta de discord del mod/admin', inline=False)
suhelp.add_field(name='!strike <nick de minecraft> <razon del strike>', value='le da o añade un strike a un jugador, lo kickea de minecraft y le avisa, le añade el rango correspondiente en discord (strike 1, 2, 3) y hace un anuncio en el canal de reportes y strikes', inline=False)
suhelp.add_field(name='!mantenimiento <razon> <tiempo minimo*> <tiempo maximo*>', value="""    activa o desactiva el modo mantenimiento del servidor y manda un anuncio en el canal de anuncios para (a)everyone

    **tiempo minimo y tiempo maximo son opcionales, solo sirven para activar el mantenimiento, al desactivar el mantenimiento no son necesarios""", inline=False)

nhelp = Embed(
            title = em_book + " COMANDOS DE SERVER MASTER " + em_book,
            description = 'Los comandos disponibles son:',
            colour = colors.get('blue')
        )
nhelp.set_footer(text="si tienes dudas, contactanos en el canal de soporte.")
nhelp.add_field(name='!wl <tu nombre de minecraft>', value="""puedes registrarte en el canal de whitelist con el comando:
    !wl <tu nombre de minecraft>
recuerda que este comando solo puedes usarlo una vez, asegurate de escribir tu nick de minecraft bien""", inline=False)
nhelp.add_field(name='!link <nombre de minecraft>', value="""con el comando:
    !link <nombre de minecraft>
puedes linkear tu discord con nuestro servidor de minecraft, esto te dejara utilizar el chat de proximidad :D

si te registraste usando !wl no es necesario que uses !link, tu discord ya esta conectado a minecraft! ;)""", inline=False)


flagwords = [
    'xray',
    'xr4y',
    'x r 4 y',
    'xr*y',
    'x r * y',
    'xr@y',
    'x r @ y',
    'x r a y',
    'x-ray',
    'x-r*y',
    'x-r@y',
    'x-r4y',
    'x ray',
    'x r*y',
    'x r4y',
    'x r@y',
    'dupe',
    'd*pe',
    'dup3',
    'd*p3',
    'dup*',
    'ilegal',
    'il*gal',
    'ileg*l',
    '1legal',
    'il3gal',
    'ileg4l',
    '1l3g4l',
    '1leg4l',
    'il3g4l',
    'ileg4l',
    'il3gal',
    'raid',
    'hack',
    'h4ck',
    'h@ck',
    'h*ck',
    'h a c k',
    'h 4 c k',
    'h *c k',
    'h @ c k',
    'trampa',
    'stash',
    'duping',
    'dup*ng',
    'dup1ng',
    'dupear',
    'dup34r',
    'dup34r',
    'dupe@r',
    'dup*ar',
    'dupe*r',
    'dup3@r',
    'dupe4r',
    'ayuda',
]

msgcsloff = """
ADVERTENCIA 
El filtro de consola ha sido desactivado
solo se enviaran reportes del chat, esto no incluira mensajes privados atravez de /msg /m /r /tell /message

para volver a activar el filtro completo porfavor use !su flagfilter consoleoff
"""

msgcslon = """
El filtro de consola ha sido activado
se mandaran reportes de todos los mensajes que contengan las palabras clave
"""

msgflgflton = """
Se ha activado el filtro de palabras, todos los mensajes con palabras que coincidan seran enviados
"""
msgflgfltoff = """
Se ha desactivado el filtro de palabras, ya no se reportara de mensajes de minecraft
"""
msgddosclsoff = """
@Owner @🟠|Administrador @Moderador 
SE HA REGISTRADO UN ATAQUE DDOS

EL FILTRO DEL CHAT SE HA DESACTIVADO PARA NO CAUSAR ERRORES

para desactivar esta funcion desactive la regla de comportamiento \"ddos_deactivate\"
"""

consolefilter = [
    'entitydamagebyentityevent',
    'java',
    'utc info] 1',
    'mcdown_pw_'
]