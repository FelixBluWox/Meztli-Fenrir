# -*- coding: utf-8 -*-
import os
import discord
from replit import db
from smconfig import *
from discord import Embed, Colour, utils
from WoxUtils import *
from discord_integrations import *
from security_cog import *
from players_cog import *
from prettier_cog import *
from web_integrations import *
from alive_progress import alive_bar
from random import randint
from time import time

TOKEN = os.getenv('DISCORD_TOKEN')
GUILD = int(os.getenv('DISCORD_GUILD'))      


wh_sm_console.send(f'[{__name__}]: creando el bot...')
allowed_mentions=discord.AllowedMentions().all()
intents = discord.Intents().all()
MessageHandler = WoxBot(command_prefix="!", guild=GUILD, name='MessageHandler', intents=intents, allowed_mentions=allowed_mentions)


@MessageHandler.command()
async def lvl(*args):
    pass

@MessageHandler.command()
async def wl(*args):
    pass

wh_sm_console.send(f'[{__name__}]: registrando eventos...  ')

@MessageHandler.event
async def on_message(message):
    if db['maintenance']:
        return
    try:
        ctx = await MessageHandler.get_context(message)
    except Exception as ex:
        error = f"Oh no, un error ha ocurrido. Error:\n{type(ex), ex, ex.__traceback__}, detalles: \n{ex.args}"
        wh_sm_console.send(f'[{__name__}]: no se pudo obtener el contexto del mensaje')
        await MessageHandler.sm_console.send(error)
        print (error)
    if ctx.guild.id != GUILD:
        return
    if ctx.author.id in non_users:
        return
    if MessageHandler.ready:
        if ctx.channel.id == MessageHandler.ch_levels.id:
            if (not ctx.valid) and (user_auth(ctx) < 1):
                await message.delete()
                return
        if ctx.channel.id == MessageHandler.ch_whitelist.id:
            if (not ctx.valid) and (user_auth(ctx) < 1):
                await message.delete()
                return
    
    get_user.cache_clear()
    mc_user = get_user(search=ctx.author.id)
    if mc_user:
        if str(mc_user['dcid']) in db['leveling']:
            if int(time()) - db['leveling'][str(mc_user['dcid'])] <= 60:
                return
        await add_xp(randint(30,50), search=mc_user['dcid'], guild=ctx.guild)
        db['leveling'].update({mc_user['dcid']:int(time())})

            




wh_sm_console.send(f'[{__name__}]: corriendo el bot...')
MessageHandler.run(TOKEN)