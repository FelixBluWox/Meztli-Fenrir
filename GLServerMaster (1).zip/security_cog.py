import discord
from replit import db
from functools import lru_cache as cache
from discord.ext.commands import *
from discord import Embed, Colour, utils
from dotenv import load_dotenv
from os import getenv
import codecs, json, sys, traceback
from WoxUtils import *
from datetime import date
from schedule import Scheduler
from smconfig import *
from discord_integrations import get_user, user_auth, wh_sm_console, wh_mc_console
from prettier_cog import *

class hierarchy(Cog):
    def __init__(self, bot) -> None:
        self.bot = bot
        print("Hierarchy cog starting...")
        self.__name__ = '[hierarchy_module]'
        wh_sm_console.send(f'inicializando {self.__name__}...')
    
    @command()
    async def _admin(self, ctx, to_rank):
        if user_auth(ctx) >= 5:
            key = get_user(ctx, to_rank)
            if key:
                await ctx.message.add_reaction(em_check)
                db["security"]["allowed_users"][key["dcid"]] = 6
                mem = ctx.guild.get_member(key['dcid'])
                db["player_base"][key["number"]]['rank'] = 'Administrador'

                banner = discord.File(await user_banner(ctx, mem.id), filename="banner.png")
                embed = embed_builder(
                    **{
                        'title':f'Felicidades {mem.nick}!!!',
                        'description':f'{mem.mention} Has sido ascendid@ a administrador :D',
                        'color':mem.color,
                        'footer':'Recuerda, un gran poder, conyeva una gran responsabilidad...',
                        'img':"attachment://banner.png"
                    }
                )
                await self.bot.ch_levels.send(file=banner, embed=embed)
            else:
                await ctx.message.add_reaction(em_cross)
                await ctx.reply('No pude encontrar ese usuario en la base de datos UwU')
        else:
            await ctx.message.add_reaction(em_cross)
            await ctx.reply('No tienes permisos para usar ese comando')
    


    
    @command()
    async def owner(self, ctx, to_rank):
        if user_auth(ctx) >= 6:
            key = get_user(ctx, to_rank)
            if key:
                await ctx.message.add_reaction(em_check)
                db["security"]["allowed_users"][key["dcid"]] = 5
                mem = ctx.guild.get_member(key['dcid'])
                db["player_base"][key["number"]]['rank'] = 'Owner'

                banner = discord.File(await user_banner(ctx, mem.id), filename="banner.png")
                embed = embed_builder(
                    **{
                        'title':f'Felicidades {mem.nick}!!!',
                        'description':f'{mem.mention} Has sido ascendid@ a owner :D',
                        'color':mem.color,
                        'footer':'SALVE GALAXAR!!!',
                        'img':"attachment://banner.png"
                    }
                )
                await self.bot.ch_levels.send(file=banner, embed=embed)
            else:
                await ctx.message.add_reaction(em_cross)
                await ctx.reply('No pude encontrar ese usuario en la base de datos UwU')
        else:
            await ctx.message.add_reaction(em_cross)
            await ctx.reply('No tienes permisos para usar ese comando')
    


    @command()
    async def admin(self, ctx, to_rank):
        if user_auth(ctx) >= 5:
            key = get_user(ctx, to_rank)
            if key:
                await ctx.message.add_reaction(em_check)
                db["security"]["allowed_users"][key["dcid"]] = 4
                mem = ctx.guild.get_member(key['dcid'])
                db["player_base"][key["number"]]['rank'] = 'Administrador'

                banner = discord.File(await user_banner(ctx, mem.id), filename="banner.png")
                embed = embed_builder(
                    **{
                        'title':f'Felicidades {mem.nick}!!!',
                        'description':f'{mem.mention} Has sido ascendid@ a administrador :D',
                        'color':mem.color,
                        'footer':'Recuerda, un gran poder, conyeva una gran responsabilidad...',
                        'img':"attachment://banner.png"
                    }
                )
                await self.bot.ch_levels.send(file=banner, embed=embed)
            else:
                await ctx.message.add_reaction(em_cross)
                await ctx.reply('No pude encontrar ese usuario en la base de datos UwU')
        else:
            await ctx.message.add_reaction(em_cross)
            await ctx.reply('No tienes permisos para usar ese comando')
    
    @command()
    async def mod(self, ctx, to_rank):
        if user_auth(ctx) >= 4:
            key = get_user(ctx, to_rank)
            if key:
                db["security"]["allowed_users"][key["dcid"]] = 3
                mem = ctx.guild.get_member(key['dcid'])
                await mem.add_roles(self.bot.rol_mod)
                wh_sm_console.send(db["player_base"][key["number"]]['rank'])
                db["player_base"][key["number"]]['rank'] = 'Moderador'
                wh_sm_console.send(db["player_base"][key["number"]]['rank'])

                banner = discord.File(await user_banner(ctx, mem.id), filename="banner.png")
                embed = embed_builder(
                    **{
                        'title':f'Felicidades {mem.nick}!!!',
                        'description':f'{mem.mention} Has sido ascendid@ a moderador :D',
                        'color':mem.color,
                        'footer':'Recuerda, un gran poder, conyeva una gran responsabilidad...',
                        'img':"attachment://banner.png"
                    }
                )
                await self.bot.ch_levels.send(file=banner, embed=embed)
            else:
                await ctx.message.add_reaction(em_cross)
                await ctx.reply('No pude encontrar ese usuario en la base de datos UwU')
        else:
            await ctx.message.add_reaction(em_cross)
            await ctx.reply('No tienes permisos para usar ese comando')
    
    @command()
    async def curador(self, ctx, to_rank):
        if user_auth(ctx) >= 4:
            key = get_user(ctx, to_rank)
            if key:
                db["security"]["allowed_users"][key["dcid"]] = 2
                mem = ctx.guild.get_member(key['dcid'])
                await mem.add_roles(self.bot.rol_cur)
                db["player_base"][key["number"]]['rank'] = 'Curador'

                banner = discord.File(await user_banner(ctx, mem.id), filename="banner.png")
                embed = embed_builder(
                    **{
                        'title':f'Felicidades {mem.nick}!!!',
                        'description':f'{mem.mention} Has sido ascendid@ a curador :D',
                        'color':mem.color,
                        'footer':'Bienvenido al comando estelar :D',
                        'img':"attachment://banner.png"
                    }
                )
                await self.bot.ch_levels.send(file=banner, embed=embed)
            else:
                await ctx.message.add_reaction(em_cross)
                await ctx.reply('No pude encontrar ese usuario en la base de datos UwU')
        else:
            await ctx.message.add_reaction(em_cross)
            await ctx.reply('No tienes permisos para usar ese comando')
    
    @command()
    async def soporte(self, ctx, to_rank):
        if user_auth(ctx) >= 3:
            key = get_user(ctx, to_rank)
            if key:
                db["security"]["allowed_users"][key["dcid"]] = 1
                mem = ctx.guild.get_member(key['dcid'])
                await mem.add_roles(self.bot.rol_hel)
                db["player_base"][key["number"]]['rank'] = 'Ayudante'

                banner = discord.File(await user_banner(ctx, mem.id), filename="banner.png")
                embed = embed_builder(
                    **{
                        'title':f'Felicidades {mem.nick}!!!',
                        'description':f'{mem.mention} Ahora eres ayudante :D',
                        'color':mem.color,
                        'footer':'Eres parte del consejo, pero no te damos el rango de maestro...',
                        'img':"attachment://banner.png"
                    }
                )
                await self.bot.ch_levels.send(file=banner, embed=embed)
            else:
                await ctx.message.add_reaction(em_cross)
                await ctx.reply('No pude encontrar ese usuario en la base de datos UwU')
        else:
            await ctx.message.add_reaction(em_cross)
            await ctx.reply('No tienes permisos para usar ese comando')
    
    @command()
    async def demote(self, ctx, to_rank, *args):
        if user_auth(ctx) >= 4:
            key = get_user(ctx, to_rank)
            if key:
                mem = ctx.guild.get_member(key['dcid'])
                db["security"]["allowed_users"].pop(key["dcid"])
                demoted_from = []

                if self.bot.rol_mod in mem.roles:
                    await mem.remove_roles(self.bot.rol_mod)
                    demoted_from.append(self.bot.rol_mod.name)
                if self.bot.rol_cur in mem.roles:
                    await mem.remove_roles(self.bot.rol_cur)
                    demoted_from.append(self.bot.rol_cur.name)
                if self.bot.rol_hel in mem.roles:
                    await mem.remove_roles(self.bot.rol_hel)
                    demoted_from.append(self.bot.rol_hel.name)

                db["player_base"][key["number"]]['rank'] = 'Jugador'

                banner = discord.File(await user_banner(ctx, mem.id), filename="banner.png")
                embed = embed_builder(
                    **{
                        'title':f'{mem.nick} Has sido degradad@ de tu rango',
                        'description':f'{mem.mention} Se te quitaron los rangos de: {" ".join(map(str,demoted_from))}, Razon: {" ".join(map(str, args))}',
                        'color':mem.color,
                        'footer':'Deshonra!!, deshorna a ti, deshonra a tu familia, deshonra a tu vaca.',
                        'img':"attachment://banner.png"
                    }
                )
                await self.bot.ch_levels.send(file=banner, embed=embed)
            else:
                await ctx.message.add_reaction(em_cross)
                await ctx.reply('No pude encontrar ese usuario en la base de datos UwU')
        else:
            await ctx.message.add_reaction(em_cross)
            await ctx.reply('No tienes permisos para usar ese comando')
    
    
    @command()
    async def strike(self, ctx, search, *razon):
        if user_auth(ctx) >= 3:
            if ctx.message.mentions:
                dcuser = ctx.message.mentions[0]
                player = get_user(ctx, search)
            else:
                player = get_user(ctx, search)
                dcuser = ctx.guild.get_member(player['dcid'])
            if not player:
                await ctx.message.add_reaction(em_cross)
                ctx.reply('No pude enconctrar ese jugador')
            razon = ' '.join(map(str, razon))

            if self.bot.rol_strike2 in dcuser.roles:
                strike_note = f'Ya acumulaste tres strikes, seras baneado por {default_ban_time}'
                strike_num = 'Tercer strike'
                await dcuser.remove_roles(self.bot.rol_strike2)
                func = self.bot.get_command('tmpban')
                await ctx.invoke(func, search, default_ban_time, strike_note)
                role = None

            elif self.bot.rol_strike1 in dcuser.roles:
                strike_note = 'Este es tu segundo strike, si vuelves a obtener un strike sera ban'
                strike_num = 'Segundo strike'
                await dcuser.remove_roles(self.bot.rol_strike1)
                role = self.bot.rol_strike2

            else:
                strike_note = 'Este es tu primer strike, si acumulas 3 strikes seras baneado temporalmente'
                strike_num = 'Primer strike'
                role = self.bot.rol_strike1
            
            strikemsg = embed_builder(
                title = f'{em_cross} Strike {em_cross}',
                description = f'{strike_num}',
                color = color('orange'),
                footer=strike_note,
                thumb=strikeimg,
                author=ctx.author.name, 
                author_img=ctx.author.avatar_url,
                fields=[
                    {'name':'Jugador', 'value':f'{dcuser.mention}\n {player["name"]}', 'inline':True},
                    {'name':'Razon', 'value':razon, 'inline':True}
                ]
            )

            await ctx.message.add_reaction(em_check)
            await self.bot.ch_srikes.send(embed=strikemsg)
            if role:
                await dcuser.add_roles(role)
            wh_mc_console.send(f'kick {player["name"]} {razon} {strike_note}')
        else:
            await ctx.message.add_reaction(em_cross)
            ctx.reply('No tienes permiso para usar ese comando')

    @command()
    async def tmpban(self, ctx, search, time, *razon):
        if user_auth(ctx) >= 3:
            if ctx.message.mentions:
                dcuser = ctx.message.mentions[0]
                player = get_user(ctx, search)
            else:
                player = get_user(ctx, search)
                dcuser = ctx.guild.get_member(player['dcid'])
            if not player:
                await ctx.message.add_reaction(em_cross)
                ctx.reply('No pude enconctrar ese jugador')

            razon = ' '.join(map(str, razon))

            if self.bot.rol_ban2 in dcuser.roles:
                ban_note = f'Ya has sido baneado del servidor 3 veces, seras baneado permanentemente.'
                ban_num = 'Tercer ban'
                await dcuser.remove_roles(self.bot.rol_ban2)
                time = 'Permanentemente'
                wh_mc_console.send(f'ban {player["name"]} {razon}, {ban_note}')
                role = None

            elif self.bot.rol_ban1 in dcuser.roles:
                ban_note = 'Este es tu segundo ban, si te vuelven a banear sera ban permanentemente'
                ban_num = 'Segundo ban'
                await dcuser.remove_roles(self.bot.rol_ban1)
                role = self.bot.rol_ban2

            else:
                ban_note = 'Este es tu primer ban, si acumulas 3 bans seras baneado permanentemente'
                ban_num = 'Primer ban'
                role = self.bot.rol_ban1
            

            banmsg = embed_builder(
                title = f'{em_ban} Ban {em_ban}',
                description = f'{ban_num}',
                color = color('red'),
                footer=ban_note,
                thumb=banimg,
                author=ctx.author.name, 
                author_img=ctx.author.avatar_url,
                fields=[
                    {'name':'Jugador', 'value':f'{dcuser.mention}\n {player["name"]}', 'inline':True},
                    {'name':'Razon', 'value':f'Baneado {time} por {razon}', 'inline':True}
                ]
            )

            await ctx.message.add_reaction(em_check)
            await self.bot.ch_srikes.send(embed=banmsg)
            if role:
                await dcuser.add_roles(role)
            wh_mc_console.send(f'tempban {player["name"]} {time} {razon}, {ban_note}')
        else:
            await ctx.message.add_reaction(em_cross)
            ctx.reply('No tienes permiso para usar ese comando')



    @Cog.listener()
    async def on_ready(self):
        print('Hierarchy cog started')
        wh_sm_console.send(f'{self.__name__}: listo!')

