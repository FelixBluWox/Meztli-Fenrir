from multiprocessing import Process
import json, codecs, requests, os
from discord_integrations import wh_sm_console

wh_sm_console.send('REPLIT INIZIALIZANDO...\n\n')

from replit import db

os.system('pip install flask[async]')

wh_sm_console.send('Obteniendo autorizacion de discord...')
TOKEN = os.getenv('DISCORD_TOKEN')
with codecs.open('header.json', 'w', encoding='utf8') as f:
    header = requests.get("https://discord.com/api/v6/",
                          headers={"Authorization": TOKEN})
    print(header)
    wh_sm_console.send(header)
    buff = header.json()
    for element in buff:
        print(element, buff[element])
    json.dump(buff, f)

print('Program starting...')
wh_sm_console.send('inicializando programa...')


def serverMaster():
    wh_sm_console.send('iniciando master.py...')
    print('Starting ServerMaster...')
    import master


def messageHandler():
    wh_sm_console.send('iniciando message_handler.py...')
    print('Starting MessageHandler...')
    import message_handler


if __name__ == '__main__':
    sMaste = Process(target=serverMaster)
    mHandler = Process(target=messageHandler)
    sMaste.start()
    mHandler.start()
    sMaste.join()
    mHandler.join()
    print('esto corre??')
