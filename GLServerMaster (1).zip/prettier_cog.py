import discord
from replit import db
from discord.ext.commands import *
from discord import Embed, Colour, utils
from WoxUtils import *
from smconfig import *
from PIL import Image, ImageOps, ImageFont, ImageDraw, ImageChops, ImageColor
from math import sqrt
from discord_integrations import get_user, user_auth, wh_sm_console
from functools import lru_cache as cache

lvl_colors = {
    10:(40,82,207),
    20:(35,207,213),
    30:(14,180,68),
    40:(158,255,101),
    50:(246,24,57),
    60:(245,15,104),
    70:(250,152,51),
    80:(250,242,82),
    90:(170,255,255),
    100:(255,255,255)
}

colors = {
    'blue':Colour.blue(),
    'blurple':Colour.blurple(),
    'dark_blue':Colour.dark_blue(),
    'dark_gold':Colour.dark_gold(),
    'dark_gray':Colour.dark_gray(),
    'dark_green':Colour.dark_green(),
    'dark_grey':Colour.dark_grey(),
    'dark_magenta':Colour.dark_magenta(),
    'dark_orange':Colour.dark_orange(),
    'dark_purple':Colour.dark_purple(),
    'dark_red':Colour.dark_red(),
    'dark_teal':Colour.dark_teal(),
    'dark_theme':Colour.dark_theme(),
    'darker_gray':Colour.darker_gray(),
    'darker_grey':Colour.darker_grey(),
    'default':Colour.default(),
    'gold':Colour.gold(),
    'green':Colour.green(),
    'greyple':Colour.greyple(),
    'light_gray':Colour.light_gray(),
    'light_grey':Colour.light_grey(),
    'lighter_gray':Colour.lighter_gray(),
    'lighter_grey':Colour.lighter_grey(),
    'magenta':Colour.magenta(),
    'orange':Colour.orange(),
    'purple':Colour.purple(),
    'random':Colour.random(),
    'red':Colour.red(),
    'teal':Colour.teal()
}
color = lambda x: colors.get(x)

@cache
def get_exp(xp:int)->str:
    if xp > 1000000:
        res = f'{round(xp/1000000, 3)}m'
    elif xp > 1000:
        res = f'{round(xp/1000, 1)}K'
    else:
        res = str(xp)
    return res

class font_str():
    def __init__(self, text:str, font:ImageFont.FreeTypeFont) -> None:
        self.text = text
        self.font = font
        self.x = font.getsize(text)[0]
        self.y = font.getsize(text)[1]
        
        
    def __repr__(self) -> str:
        return self.text


def embed_builder(**ops):
    'title:any | description:any | color:dc_color | footer:any | img:url/none | thumb:url/none | fields:List[Dict]:{name:any, value:any, inline:bool}'

    embd = Embed(
            title = ops['title'],
            description = ops['description'],
            colour = ops['color']
        )
    if 'footer' in ops:
        embd.set_footer(text=ops['footer'])
    if 'thumb' in ops:
        embd.set_thumbnail(url=ops['thumb'])
    if 'img' in ops:
        embd.set_image(url=ops['img'])
    if 'author' in ops:
        embd.set_author(name=ops['author'], icon_url=ops['author_img'])
    if 'fields' in ops:
        for field in ops['fields']:
            embd.add_field(name=field['name'], value=field['value'], inline=field['inline'])

    return embd

@cache
async def user_banner(ctx=False, search=False, guild=False):

    if ctx:
        if ctx.message.mentions:
            dcuser = ctx.message.mentions[0]
            mcuser = get_user(ctx, search)
        elif search:
            mcuser = get_user(ctx, search)
            dcuser = ctx.guild.get_member(mcuser['dcid'])
        else:
            dcuser = ctx.author
            mcuser = get_user(ctx, ctx.author.id)
    else:
        if search and guild:
            mcuser = get_user(search=search)
            dcuser = guild.get_member(mcuser['dcid'])
        else:
            raise TypeError("if no context, search and guild must be provided")

    if mcuser:
            
        rank = font_str(mcuser['rank'], ImageFont.truetype("./images/Comfortaa-Bold.ttf", 30))
        name = font_str(dcuser.name, ImageFont.truetype("./images/Comfortaa-Regular.ttf", 30))
        nick = font_str((dcuser.nick if dcuser.nick else dcuser.name), ImageFont.truetype("./images/Comfortaa-Bold.ttf", 52))
        disc = font_str(f'#{dcuser.discriminator}', ImageFont.truetype("./images/Comfortaa-Light.ttf", 28))
        smal = lambda x: font_str(x, ImageFont.truetype("./images/Comfortaa-Regular.ttf", 26))

        dc_str = smal('DC:')
        mc_str = smal('MC:')

        lvl = mcuser['level']
        mcname = font_str(mcuser['name'], ImageFont.truetype("./images/Comfortaa-Bold.ttf", 56))
        xp = mcuser['xp']
        nextlvl = mcuser['nxtlvl']
        exp = font_str(f'{get_exp(xp)}/{get_exp(nextlvl)} xp', ImageFont.truetype("./images/Comfortaa-Regular.ttf", 32))
        lvl_str = font_str('nivel:', ImageFont.truetype("./images/Comfortaa-Regular.ttf", 32))
        pos_str = font_str('rank:', ImageFont.truetype("./images/Comfortaa-Regular.ttf", 32))
        level = font_str(f"{mcuser['level']}", ImageFont.truetype("./images/Comfortaa-Bold.ttf", 96))
        pos_rank = font_str(f"#{mcuser['ranking']}", ImageFont.truetype("./images/Comfortaa-Bold.ttf", 96))

        await dcuser.avatar_url.save(fp = "./images/tempimage.webp")
        template = Image.open("./images/gltemplatebg.png")
        mask = Image.open("./images/cicularmask.png").convert('L')
        pfp = Image.open("./images/tempimage.webp").convert("RGBA")
        symbol = Image.open(f"./images/{mcuser['rank']}.png")
        finalpfp = ImageOps.fit(pfp, (mask.size), centering=(0.5, 0.5))
        finalpfp.putalpha(mask)
        urs_color = ImageColor.getrgb(str(dcuser.color))
        decal = Image.new('RGBA', (1050, 330), urs_color)
        decalmask = Image.open("./images/templatedecalmask.png").convert('L')
        decal.putalpha(decalmask)
        bar = int((534 / nextlvl) * xp)
        xp_bar_placeholder = Image.new('RGBA', (534, 49), (45, 56, 50))
        xp_bar_full = Image.new('RGBA', (bar, 49), urs_color)
        xp_bar_full = ImageChops.invert(xp_bar_full)
        xp_bar_placeholder.paste(xp_bar_full, (0,0))
        xp_bar_mask = Image.open("./images/xpbar.png").convert('L')
        xp_bar_placeholder.putalpha(xp_bar_mask)

        lev_bar = None
        for lev in reversed(lvl_colors):
            if lvl - lev > 0:
                lev_bar = Image.new('RGB', (20, 330), lvl_colors[lev])
                break

        if lev_bar:
            if lev + 7 < lvl < lev + 10:
                template.paste(lev_bar, (904,0))
                template.paste(lev_bar, (940,0))
                template.paste(lev_bar, (976,0))
            elif lev + 4 < lvl < lev + 8:
                template.paste(lev_bar, (922,0))
                template.paste(lev_bar, (958,0))
            else:
                template.paste(lev_bar, (940,0))

        template = Image.alpha_composite(template, decal)
        template.paste(finalpfp, (15,15), finalpfp)
        template.paste(symbol, (850,0), symbol)
        template.paste(xp_bar_placeholder, (315,266), xp_bar_placeholder)
        draw = ImageDraw.Draw(template)

        white = (255,255,255)
        gray = (170, 170, 170)

        mid = lambda text1, text2: (text1.y/2) - (text2.y/2)
        xpos = lambda text, vert: int(sqrt(abs((177 ** 2) - ((175 - (vert + (text.y * 2))) ** 2))))

        vertical = 15
        horizontal = 165 + xpos(rank, vertical)
        draw.text((horizontal, vertical), rank.text, urs_color, font=rank.font)
        horizontal += rank.x + 10
        draw.text((horizontal, vertical), name.text, gray, font=name.font)
        horizontal += name.x + 2
        draw.text((horizontal, vertical), disc.text, gray, font=disc.font)
        vertical += rank.y + 6
        horizontal = 165 + xpos(dc_str, vertical)
        draw.text((horizontal, vertical + mid(nick, dc_str)), dc_str.text, gray, font=dc_str.font)
        horizontal += dc_str.x + 5
        draw.text((horizontal, vertical), nick.text, white, font=nick.font)
        vertical += nick.y + 6
        horizontal = 165 + xpos(mc_str, vertical)
        draw.text((horizontal, vertical + mid(mcname, mc_str)), mc_str.text, gray, font=mc_str.font)
        horizontal += mc_str.x + 5
        draw.text((horizontal, vertical), mcname.text, white, font=mcname.font)
        vertical += mcname.y + 6
        horizontal = 165 + xpos(lvl_str, vertical)
        draw.text((horizontal, vertical + mid(level, lvl_str)), lvl_str.text, gray, font=lvl_str.font)
        horizontal += lvl_str.x + 6
        draw.text((horizontal, vertical), level.text, white, font=level.font)
        horizontal += level.x + 6
        draw.text((horizontal, vertical + mid(pos_rank, pos_str)), pos_str.text, gray, font=pos_str.font)
        horizontal += pos_str.x + 6
        draw.text((horizontal, vertical), pos_rank.text, white, font=pos_rank.font)
        horizontal = 582 - (exp.x / 2)
        vertical = 290.5 - (exp.y /2)
        draw.text((horizontal, vertical), exp.text, white, font=exp.font)

        template.save('./images/tempimage.png')
        return './images/tempimage.png'
    else:
        return None

class prettier(Cog):
    def __init__(self, bot) -> None:
        self.bot = bot
        self.__name__ = '[prettier_module]'
        wh_sm_console.send(f'inicializando {self.__name__}...')
        print("Prettier cog starting...")


    @command()
    async def getinfo(self, ctx, *args):
        print(args)
        search = None
        if args:
            search = args[0]
        if user_auth(ctx) < 1:
            await ctx.reply('No tienes permiso para usar ese comando')
            return

        await ctx.message.add_reaction(em_check)
        print(search)
        mcuser = get_user(ctx, search)
        print(mcuser)
        if not mcuser:
            await ctx.reply('No pude encontrar al usuario .-.')
            return

        dcmem = ctx.guild.get_member(mcuser['dcid'])

        incid = ['El jugador', '', '']

        if dcmem:
            if self.bot.rol_strike1 in dcmem.roles:
                incid[1] = 'tiene 2 strikes y'
            elif self.bot.rol_strike2 in dcmem.roles:
                incid[1] = 'tiene 1 strike y'
            else:
                incid[1] = 'no tiene strikes,'

            if self.bot.rol_ban1 in dcmem.roles:
                incid[2] = 'tiene 2 bans'
            elif self.bot.rol_ban2 in dcmem.roles:
                incid[2] = 'tiene 1 ban'
            else:
                incid[2] = 'no tiene bans'
            incidents = ' '.join(map(str, incid))
        else:
            incidents = 'No se pudo acceder a la informacion del miembro'
        
        banner = discord.File(await user_banner(ctx, dcmem.id), filename="banner.png")
        embed = embed_builder(
            **{
                'title':'Informacion del jugador',
                'description':f'{dcmem.mention}',
                'color':dcmem.color,
                'footer':f"Jugador numero{mcuser['number']}: {dcmem.name}{dcmem.discriminator}, {mcuser['name']}",
                'img':"attachment://banner.png",
                'thumb':dcmem.avatar_url,
                'fields':[
                    {'name':'Nick', 'value':mcuser['name'], 'inline':True},
                    {'name':'Nombre', 'value':(dcmem.name if dcmem.name else mcuser['dcname']), 'inline':True},
                    {'name':'Discord', 'value':(dcmem.mention if dcmem.mention else None), 'inline':True},
                    {'name':'MC UUID', 'value':mcuser['uuid'], 'inline':True},
                    {'name':'Apodo', 'value':(dcmem.name if dcmem.name else "No tiene"), 'inline':True},
                    {'name':'DC ID', 'value':dcmem.id, 'inline':True},

                    {'name':'Incidentes', 'value':incidents, 'inline':True}
                ]
            }
        )
        await ctx.reply(file=banner, embed=embed)

    @command()
    async def lvl(self, ctx):
        if ctx.channel.id == self.bot.ch_levels.id:
            banner = await user_banner(ctx)
            if banner:
                banner = discord.File(banner)
                await ctx.reply(file=banner)
            else:
                await ctx.reply('No pude encontrar al usuario .-.')
        else:
            await ctx.reply(f'Usa el comando en el canal {self.bot.ch_levels.mention}')

    @Cog.listener()
    async def on_ready(self):
        print('Prettier cog started')
        wh_sm_console.send(f'{self.__name__}: listo!')
