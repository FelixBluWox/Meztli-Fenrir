# -*- coding: utf-8 -*-
import os
import discord
from replit import db
from datetime import date
from smconfig import *
import string
from dotenv import load_dotenv
from discord.ext import commands
from discord import Embed, Colour, utils
import codecs, json
from WoxUtils import *
from discord_integrations import *
from players_cog import *
from security_cog import *
from prettier_cog import *
from web_integrations import *
from alive_progress import alive_bar
from random import randint
from time import time

load_dotenv('token.env')
TOKEN = os.getenv('DISCORD_TOKEN')
GUILD = int(os.getenv('DISCORD_GUILD'))



wh_sm_console.send(f'[{__name__}]: creando el bot...')
allowed_mentions=discord.AllowedMentions().all()
intents = discord.Intents().all()
ServerMaster = WoxBot(command_prefix="!", guild=GUILD, name='ServerMaster', intents=intents, allowed_mentions=allowed_mentions)
ServerMaster.add_cog(hierarchy(ServerMaster))
ServerMaster.add_cog(user_manager(ServerMaster))
ServerMaster.add_cog(prettier(ServerMaster))
ServerMaster.add_cog(web_server(ServerMaster, import_name=__name__,template_folder='./webpage', static_folder = './webpage'))

wh_sm_console.send(f'[{__name__}]: registrando comandos...  ')

@ServerMaster.command()
async def mantenimiento(ctx, *args):
    razon, tmin, tmax = '', 0, 0
    if user_auth(ctx) >= 3:
        if len(args) >= 1:
            razon = args[0]
        if len(args) >= 2:
            tmin = args[1]
        if len(args) >= 3:
            tmax = args[2]
        if not db['server_maintenance']:
            db['server_maintenance'] = True
            anouncement = Embed(
                title = em_tools + " SERVIDOR EN MANTENIMIENTO " + em_tools,
                description = razon,
                colour = colors.get('dark_red')
            )

            anouncement.set_author(name=ctx.author.name, icon_url=ctx.author.avatar_url)

            anouncement.set_footer(text="pronto avisaremos cuando vuelva a estar en linea.")
            anouncement.set_thumbnail(url=repairimg)

            anouncement.add_field(
                    name = 'Tiempo minimo', 
                    value = tmin, 
                    inline = True
                )

            anouncement.add_field(
                    name = 'Tiempo maximo', 
                    value = tmax, 
                    inline = True
                )
            wh_mc_console.send('maintenance on')
            
        elif db['server_maintenance']:
            db['server_maintenance'] = False
            anouncement = Embed(
                title = em_world + " SERVIDOR EN LINEA " + em_world,
                description = razon,
                colour = colors.get('blurple')
            )

            anouncement.set_author(name=ctx.author.name, icon_url=ctx.author.avatar_url)

            anouncement.set_footer(text="diviertanse ;).")
            anouncement.set_image(url=mainimg)
            wh_mc_console.send('maintenance off')

        await ServerMaster.ch_anuncios.send("@everyone")
        await ctx.message.add_reaction(em_check)
        await ServerMaster.ch_anuncios.send(embed=anouncement)
    else:
        await ctx.message.add_reaction(em_cross)
        await ctx.channel.send("No tienes permiso para usar ese comando")

@ServerMaster.command()
async def botmatto(ctx):
    print(db['maintenance'])
    if user_auth(ctx) >= 3:
        await ctx.message.add_reaction(em_check)
        if db['maintenance']:
            db['maintenance'] = False
            print("mantenimiento desactivado...")
            wh_sm_console.send("mantenimiento desactivado...")
            await ctx.reply("Se ha desactivado el modo mantenimiento")
            return
        if not db['maintenance']:
            db['maintenance'] = True
            print("mantenimiento activado...")
            wh_sm_console.send("mantenimiento activado...")
            await ctx.reply("Se ha activado el modo mantenimiento")
            return
        print(db['maintenance'])
    else:
        await ctx.message.add_reaction(em_cross)
        await ctx.channel.send("No tienes permiso para usar ese comando")

@ServerMaster.command()
async def test(ctx):
    await ctx.reply('estoy vivo!!!  -v2.0')
    await ctx.reply(f'base de datos:{db["security"]}')

@ServerMaster.command()
async def user_entry(ctx, search):
    if user_auth(ctx) >= 3:
        player = get_user(ctx, search)
        plaayer = db["player_base"][player["number"]]
        print (player)
        print (plaayer)
        savejson(str(dict(player)), 'usrtemp.json')
        await ctx.reply(file=discord.File('./usrtemp.json'))
        savejson(str(dict(plaayer)), 'usrtemp.json')
        await ctx.reply(file=discord.File('./usrtemp.json'))

@ServerMaster.command()
async def echo(ctx, *message):
    await ctx.send(' '.join(map(str, message)))




@ServerMaster.command()
async def savewl(ctx):
    buffer = list(db.dumps(db['player_base']))
    savejson(buffer, 'whitelist.json')
    await ctx.message.add_reaction(em_check)
    await ctx.reply(file=discord.File('./whitelist.json'))


@ServerMaster.command()
async def mc(ctx, *com):
    if user_auth(ctx) > 3:
        wh_mc_console.send(' '.join(map(str, com)))
    else:
        await ctx.message.add_reaction(em_cross)
        await ctx.reply("no tienes permiso para usar ese comando")


@ServerMaster.command()
async def regitemslist(ctx):
    if user_auth(ctx) > 2:
        buffer = list(db.dumps(db['new_item_sunmits']))
        savejson(buffer, 'submited_items.json')
        await ctx.message.add_reaction(em_check)
        await ctx.reply(file=discord.File('./submited_items.json'))

@ServerMaster.command()
async def createtop(ctx):
    if user_auth(ctx) > 3:
        top = []
        for i in range(10):
            top.append(db["player_base"][db["ranking"][i]])
        savejson(top, 'baltop.json')
        await ctx.message.add_reaction(em_check)
        await ctx.reply(file=discord.File('./baltop.json'))


@ServerMaster.command()
async def clearlevels(ctx):
    if user_auth(ctx) > 4:
        await ctx.message.add_reaction(em_check)
        for player in db["player_base"]:
            db["player_base"][player["number"]].update(
                {
                    "xp":0,
                    "level":1,
                    "nxtlvl":200
                }
            )
        update_ranking()
        await ctx.reply('niveles reiniciados')



@ServerMaster.command()
async def regitems(ctx):
    mc_user = get_user(ctx, ctx.author.id)
    if mc_user:
        await ctx.message.add_reaction(em_check)
        await ctx.reply('has registrado tu inventario :D')
        db['new_item_sunmits'].update({mc_user['name']:mc_user})
    else:
        await ctx.message.add_reaction(em_cross)
        await ctx.reply('Hmmm pareceque ese usuario no esta registrado :^P')
    



wh_sm_console.send(f'[{__name__}]: registrando eventos...  ')

@ServerMaster.after_message
async def after_message(ctx, message):
    if ctx.channel == ServerMaster.sm_console:
        if ctx.author.id == 932174037432557568:
            if '$command$' in message.content:
                content = message.content.split('/')
                if content[1] == 'strike':
                    command = ServerMaster.get_command('strike')
                    await ctx.invoke(command, content[2], content[3])
                if content[1] == 'tmpban':
                    command = ServerMaster.get_command('tmpban')
                    await ctx.invoke(command, content[2], content[3], content[4])
                await message.delete()
                
    pass

@ServerMaster.thread_after_message
async def after_message(ctx, message):
    pass

ServerMaster.run_wsv()
wh_sm_console.send(f'[{__name__}]: corriendo el bot...')
ServerMaster.run(TOKEN)
