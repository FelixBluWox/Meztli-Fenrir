import codecs, requests, os
from googletrans import Translator
translator = Translator()
TOKEN = os.getenv('DISCORD_TOKEN')

def get_name(obj):
    return [objname for objname, oid in globals().items()
            if id(oid)==id(obj)][0]

def strtobol(val):
    v = val.lower()
    if v == 'true':
        return True
    elif v == 'false':
        return False
    else:
        return None

def savejson(json_file: iter, name:str):
    json_file = ''.join(map(str, json_file))
    json_file.split(',')
    json_file.split('{')
    json_file.split('}')
    new = []
    tab = False
    for e in json_file:
        if e != ',':
            if e != '{':
                if e !='}':
                    new.append(e)
                else:
                    new.append('\n\t')
                    new.append(e)
                    tab = False
            else:
                new.append('\t')
                new.append(e)
                new.append('\n\t\t')
                tab = True
        else:
            new.append(e)
            new.append('\n')
            if tab:
                new.append('\t\t')

    with codecs.open(name, 'w', encoding='utf8') as f:
            f.write(''.join(map(str, new)))
            f.close()



def get_dc_http():
    error = True
    print('Getting discod HTTP header')
    with codecs.open('./webpage/botstate.html', 'r', encoding='utf8') as f:
        html = f.read()
        f.close
        html = html.split('\n')
        mark = []
        for index, line in enumerate(html):
            if '<!--MARKER-->' in line:
                mark.append(index)
                html.pop(index)

        html = ['\n'.join(map(str, html[:mark[0]])), '\n'.join(map(str, html[mark[0]:mark[1]])), '\n'.join(map(str, html[mark[1]:]))]
            
        header = requests.get("https://discord.com/api/v6/", headers={"Authorization": TOKEN})
        buff = header.json()

        code = buff["code"]
        #msg = translation_input = translator.translate(buff["message"], dest="es")
        msg = buff["message"]
        #msg = msg.text

        if '404' in buff['message']:
            code = 404

        if code != 404:
            htmlmsg = [
                "Hubo un error al conectarse con discord",
                "Seguramente la API esta negando el acceso por algun error, esto quiere decir que el bot no podra encender hasta que la API nos desbloquee"
                ]
            error = True
            errormsg = f"""
    Error {code}

    Hubo un error al obtener la respuesta de discord

    {msg}

    el bot intentara reconectarse en cuanto sea posible
            """
            print(errormsg)
        else:
            htmlmsg = [
                "Conexion establecida",
                "Todo esta funcionando como deberia :D"
                ]
            code = 200
            msg = "Se ha podido conectar con la API de discord satisfactoriamente"
            print(f"""
    Codigo {code}

    {msg}

    *Todo funcionando correcta mente
            """)


        html_snipet = f"""            <!--MARKER-->
            <header id="botinfo">
                <table id="bottbl">
                    <tr>
                    <td><img id="botimg" src="webpage/IMG/glfixi.png" alt="404img"></td>
                    <td id = "fourzerotext"><h1>{code}.</h1></td>
                    </tr>
                </table>
                <h1>{htmlmsg[0]}</h1>
                <h2>&nbsp</h2>
                <h2>{htmlmsg[1]}</h2>
                <h3>&nbsp</h3>
                <h2>Mensaje de discord:</h2>
                <h3>{msg}</h3>

            </header>
            <!--MARKER-->"""
        
        with codecs.open('./webpage/botstate.html', 'w', encoding='utf8') as f:
            html[1] = html_snipet
            f.write('\n'.join(map(str, html)))
            f.close

    return error