import discord, os, sys, traceback
from functools import lru_cache as cache
from replit import db
from smconfig import *
from discord.ext.commands import *
from WoxUtils import *
from discord import Webhook, RequestsWebhookAdapter
from time import time
from random import randint
from threading import Thread
import asyncio

wh_anuncios = Webhook.partial(int(os.getenv('wh_anuncios_id')), os.getenv('wh_anuncios_token'), adapter=RequestsWebhookAdapter())
wh_sm_console = Webhook.partial(int(os.getenv('wh_sm_console_id')), os.getenv('wh_sm_console_token'), adapter=RequestsWebhookAdapter())
wh_mc_console = Webhook.partial(int(os.getenv('wh_mc_console_id')), os.getenv('wh_mc_console_token'), adapter=RequestsWebhookAdapter())
wh_wf_console = Webhook.partial(int(os.getenv('wh_wf_console_id')), os.getenv('wh_wf_console_token'), adapter=RequestsWebhookAdapter())

wh_staff = Webhook.partial(int(os.getenv('wh_staff_id')), os.getenv('wh_staff_token'), adapter=RequestsWebhookAdapter())
wh_levels = Webhook.partial(int(os.getenv('wh_levels_id')), os.getenv('wh_levels_token'), adapter=RequestsWebhookAdapter())
wh_reportes = Webhook.partial(int(os.getenv('wh_reportes_id')), os.getenv('wh_reportes_token'), adapter=RequestsWebhookAdapter())

non_users = {929987990514720778,159985870458322944,276060004262477825,155149108183695360,185476724627210241,429457053791158281,83010416610906112, 252128902418268161,865417728579076106,375805687529209857,557628352828014614, 931059271888699412, 931060816978018334, 932174037432557568, 903821028696924241, 931855002971025460, 933239107155529828}

server_master_alias = {931059271888699412, 931060816978018334, 932174037432557568, 903821028696924241, 931855002971025460, 933239107155529828, 865417728579076106}

def run_async(func, *args, **kwargs):
    new_thread = Thread(target=asyncio.run, args=(func(*args, **kwargs),))
    new_thread.start()

def thread_run(func, *args, **kwargs):
    new_thread = Thread(target=func, args=(*args, *kwargs,))
    new_thread.start()

@cache
def get_user(ctx=False, search=False)->dict:
    for player in db["player_base"]:
        if (search == player["dcid"]):
            return player
        if ctx:
            if ctx.message.mentions:
                if ctx.message.mentions[0].id == player["dcid"]:
                    return player
        if (search == player["uuid"]):
            return player
        if (search == player["name"]):
            print('cual es tu puto problemaaaaaaa')
            return player

    return False


@cache
def user_auth(ctx=False, search=False)->int:
    if ctx:
        if str(ctx.author.id) in db["security"]["allowed_users"]:
            return db["security"]["allowed_users"][str(ctx.author.id)]
        elif ctx.author.name in db["security"]["allowed_users"]:
            return db["security"]["allowed_users"][ctx.author.name]
        elif type(ctx.author) == discord.Member:
            for role in ctx.author.roles:
                if role.name in db["security"]["allowed_users"]:
                    return db["security"]["allowed_users"][role.name]
        else:
            return -1
    else:
        user = get_user(search=search)
        if user:
            if str(user['dcid']) in db["security"]["allowed_users"]:
                return db["security"]["allowed_users"][str(ctx.author.id)]
            elif user['dcname'] in db["security"]["allowed_users"]:
                return db["security"]["allowed_users"][ctx.author.name]
    return -1

class WoxBot(Bot):
    def __init__(self, command_prefix, guild, name='WoxBot', description=None, **options):
        super().__init__(command_prefix, description=description, **options)
        self.guild_id = guild
        self.__name__ = name
        self.on_message_threads = {}
        self.ready = False
        wh_sm_console.send(f'iniciando [{self.__name__}]...')
    
    def on_guild():
        async def predicate(self, ctx):
            if ctx.guild is None:
                raise NoPrivateMessage() 
            return ctx.guild.id == self.guild_id
        return check(predicate)
    
    def after_ready(self, func):
        self.function_after_ready = func

    async def function_after_ready(self):
        pass
    
    def after_message(self, func):
        self.function_after_message = func

    async def function_after_message(self, ctx, message):
        pass
    
    def thread_after_message(self, func):
        self.function_thread_after_message = func

    async def function_thread_after_message(self, ctx, message):
        pass

    def getChannels(self):
        wh_sm_console.send(f'[{self.__name__}]: obteniendo canales de texto...')

        self.ch_whitelist = self.get_channel(int(getenv('ch_whitelist')))
        self.ch_reportes = self.get_channel(int(getenv('ch_reportes')))
        self.ch_srikes = self.get_channel(int(getenv('ch_srikes')))
        self.ch_anuncios = self.get_channel(int(getenv('ch_anuncios')))
        self.ch_ranks = self.get_channel(int(getenv('ch_ranks')))
        self.ch_levels = self.get_channel(int(getenv('ch_levels')))
        self.mc_console = self.get_channel(int(getenv('mc_console')))
        self.wf_console = self.get_channel(int(getenv('wf_console')))
        self.sm_console = self.get_channel(int(getenv('sm_console')))

    def getRoles(self):
        wh_sm_console.send(f'[{self.__name__}]: obteniendo roles...')

        self.rol_ghost = utils.get(self.guild.roles, id =int(getenv('rol_ghost')))
        self.rol_strike1 = utils.get(self.guild.roles, id =int(getenv('rol_strike1')))
        self.rol_strike2 = utils.get(self.guild.roles, id =int(getenv('rol_strike2')))
        self.rol_ban1 = utils.get(self.guild.roles, id =int(getenv('rol_ban1')))
        self.rol_ban2 = utils.get(self.guild.roles, id =int(getenv('rol_ban2')))
        self.rol_owner = utils.get(self.guild.roles, id =int(getenv('rol_owner')))
        self.rol_admin = utils.get(self.guild.roles, id =int(getenv('rol_admin')))
        self.rol_mod = utils.get(self.guild.roles, id =int(getenv('rol_mod')))
        self.rol_cur = utils.get(self.guild.roles, id =int(getenv('rol_cur')))
        self.rol_hel = utils.get(self.guild.roles, id =int(getenv('rol_hel')))
        self.rol_alpha = utils.get(self.guild.roles, id =int(getenv('rol_alpha')))
        self.rol_beta = utils.get(self.guild.roles, id =int(getenv('rol_beta')))
        self.rol_gama = utils.get(self.guild.roles, id =int(getenv('rol_gama')))
        self.rol_vip = utils.get(self.guild.roles, id =int(getenv('rol_vip')))
        
    @on_guild()
    def addChannel(self, name:str, **kwargs)->None:
        """
        Adds a chanel to the bot

        use
            addChannel(<name>, <id, env or channel>)
        then
            <bot>.<name> 
        to use the channel

        takes
            id: int, discord ID of the channel to add

            env: str, env key if the ID is on a .env file 

            channel: discord.channel.TextChannel, discord channel to 
            
        """
        wh_sm_console.send(f'[{self.__name__}]: añadiendo un nuevo canal de texto...')
        
        if not kwargs:
            raise TypeError('No key argumrnt was provided, must give either "id", "env" or "channel" but None was given')
        elif 'id' in kwargs:
            channel = self.get_channel(kwargs['id'])
        elif 'env' in kwargs:
            channel = self.get_channel(int(os.getenv(kwargs['env'])))
        elif 'channel' in kwargs:
            channel = kwargs['channel'] 
        else:
            raise TypeError(f'The Keywords must be "id", "env" or "channel", got {", ".join(map([f"{key}, {kwargs[key]}" for key in kwargs], str))} instead')
        setattr(self, name, channel)
        
    @on_guild()
    async def on_message(self, message):
        try:
            ctx = await self.get_context(message)
        except Exception as ex:
            error = f"Oh no, un error ha ocurrido. Error:\n{type(ex), ex, ex.__traceback__}, detalles: \n{ex.args}"
            wh_sm_console.send(f'[{self.__name__}]: no se pudo obtener el contexto del mensaje')
            await self.sm_console.send(error)
            print (error)
        
        if db['maintenance']:
            if user_auth(ctx) < 3:
                if ctx.valid:
                    await message.channel.send("El bot esta en mantenimiento, intenta mas tarde")
                    return
    
        if ctx.valid:
            try:
                await self.process_commands(message)
            except Exception as ex:
                error = f"Oh no, un error ha ocurrido. Error: {type(ex).__name__}, detalles: \n{ex.args}"
                wh_sm_console.send(f'[{self.__name__}]: ocurrio un error al ejecutar un comando')
                await self.sm_console.send(error)
                print (error)
        else:
            run_async(self.function_thread_after_message, ctx, message)
            await self.function_after_message(ctx, message)
            return

    @on_guild()
    async def on_ready(self):
        self.guild = self.get_guild(self.guild_id)
        self.getChannels()
        self.getRoles()
        self.ready = True
        await self.function_after_ready()
        wh_sm_console.send(f'[{self.__name__}]: listo!')
        print(f"{self.__name__} Running!!!")
    

    async def on_command_error(self, ctx, error):
        if hasattr(ctx.command, 'on_error'):
            return

        ignored = (CommandNotFound, )

        error = getattr(error, 'original', error)

        if isinstance(error, ignored):
            return

        if isinstance(error, DisabledCommand):
            await ctx.send(f'{ctx.command} has been disabled.')

        elif isinstance(error, NoPrivateMessage):
            try:
                await ctx.author.send(f'{ctx.command} can not be used in Private Messages.')
            except discord.HTTPException:
                pass

        else:
            await ctx.message.add_reaction(em_cross)
            await ctx.reply("Algo salio mal con el comando UwU")
            await self.sm_console.send(f'Ignoring exception in command {ctx.command}:\n{type(error), error, error.__traceback__}')
            print('Ignoring exception in command {}:'.format(ctx.command), file=sys.stderr)
            traceback.print_exception(type(error), error, error.__traceback__, file=sys.stderr)






